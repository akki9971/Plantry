import React from 'react'

export const FixedChatBtn = () => {
  return (
    <>
        <button className="fixed_chat_btn"></button>
    </>
  )
}
