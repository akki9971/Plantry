import React from 'react'

export const SectionBox = (props) => {
  return (
    <>
        <div className="sectionBox">
            {props.children}
        </div>
    </>
  )
}
