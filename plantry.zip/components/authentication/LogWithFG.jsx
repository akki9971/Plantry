import React from 'react'

export const LogWithFG = () => {
    return (
        <>
            <div className="logWithFG">
                <h6 className="text-center">
                    <button className="d-sm-block btn btn-danger px-2 me-2 me-sm-0 px-sm-4 py-1 mb-sm-2">Login with Google</button>
                    <button className="d-sm-block btn btn-primary px-2 px-sm-3 py-1">Login with Facebook</button>
                </h6>
                <h6 className="text-center">
                </h6>
            </div>
        </>
    )
}
